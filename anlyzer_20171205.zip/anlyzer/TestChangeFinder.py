# -*- coding: utf-
import matplotlib.pyplot as plt
import changefinder
import numpy as np
"""
data=np.concatenate([np.random.normal(0.7, 0.05, 300),
                     np.random.normal(1.5, 0.05, 300),
                     np.random.normal(0.6, 0.05, 300),
                     np.random.normal(1.3, 0.05, 300)])
"""

data = [
30,33,32,25,27,26,24,27,30,29,31,25,27,29,32,32,23,25,20,77,138,148,174,202,206,220,219,147,179,262,284,303,265,224,179,112,53,45,27,18,21,17,15,13,21,23,17,22,18,16,19,19,19,20,22,18,9,10,26,18,20,18,18,14,23,80,160,219,223,201,178,139,143,169,169,67,94,119,149,198,157,85,52,39,39,36,35,24,32,32,27,22,30,27,28,24,30,31,31,31,33,28,27,24,29,26,26,26,25,33,28]

#cf = changefinder.ChangeFinder(r=0.01, order=1, smooth=7)
#cf = changefinder.ChangeFinder(r=0.01, order=2, smooth=14)
cf = changefinder.ChangeFinder(r=0.1, order=3, smooth=20)
# r=0.5: Not use
# r=0.5: 何とか
#cf = changefinder.ChangeFinder(r=0.05, order=1, smooth=7)

#cf = changefinder.ChangeFinderARIMA(term=10, smooth=7, order=(1,0,0))

ret = []
for i in data:
    score = cf.update(i)
    ret.append(score)

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(ret)
ax2 = ax.twinx()
ax2.plot(data,'r')
plt.show()