#coding:utf-8

import numpy as np
import matplotlib.pyplot as plt


# 配列の前半後半で比較
def compare_movement(pdata):
    # 面積
    datasize = len(pdata)
    halfvalue = datasize // 2
    firsthalf = 1 # 最低1を設定
    secondhalf = 1 # 最低1を設定
    for v in range(halfvalue):
        firsthalf += pdata[v]
    for v in range(halfvalue, datasize):
        secondhalf += pdata[v]

    print(u"面積前半：", firsthalf)
    print(u"面積後半：", secondhalf)
    return firsthalf, secondhalf

"""
#x = [1,2,3,4]
#y = [4,5,6,7]

#ary = [[10], [20], [30], [40], [50]]

#data = np.array([30,33,32,25,27,26,24,27,30,29,31,25,27,29,32,32,23,25,20,77,138,148,174,202,206,220,219,147,179,262,284,303,265,224,179,112,53,45,27,18,21,17,15,13,21,23,17,22,18,16,19,19,19,20,22,18,9,10,26,18,20,18,18,14,23,80,160,219,223,201,178,139,143,169,169,67,94,119,149,198,157,85,52,39,39,36,35,24,32,32,27,22,30,27,28,24,30,31,31,31,33,28,27,24,29,26,26,26,25,33,28])
#data = np.array([20,77,138,148,174,202,206,220,219,147,179,262,284,303,265,224,179,112,53,45,27])
data = np.array([23,80,160,219,223,201,178,139,143,169,169,67,94,119,149,198,157,85,52,39,39,36,35,24])
#data = np.array([10, 20, 25, 40, 50, 40, 30, 20, 10])
#data = np.array([10, 20, 25, 40, 50, 40, 30, 20, 10])

print(u"平均値：", np.mean(data))
print(u"中央値：", np.median(data))
print(u"最大値：", np.amax(data))
print(u"最小値：", np.amin(data))

# 面積
fiesthalf, secondhalf = compare_movement(data)

"""
"""
datasize = len(data)
halfvalue = datasize//2
fiesthalf = 0
secondhalf = 0
for v in range(halfvalue):
    fiesthalf +=  data[v]
for v in range(halfvalue, datasize):
    secondhalf += data[v]
"""

"""
#fig, axes = plt.subplots(figsize=(7, 4))
#axes.plot(x, y, 'r')

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)
#ax.plot(data, 'r')
# ヒストグラムを出力
#ax.hist(data, 5)

# 棒グラフ
xdata = np.array([])
for i in range(len(data)):
    xdata = np.append(xdata, i+1)
ax.bar(xdata, data)

plt.show()
"""
