# -*- coding: utf-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

data = [
30,33,32,25,27,26,24,27,30,29,31,25,27,29,32,32,23,25,20,77,138,148,174,202,206,220,219,147,179,262,284,303,265,224,179,112,53,45,27,18,21,17,15,13,21,23,17,22,18,16,19,19,19,20,22,18,9,10,26,18,20,18,18,14,23,80,160,219,223,201,178,139,143,169,169,67,94,119,149,198,157,85,52,39,39,36,35,24,32,32,27,22,30,27,28,24,30,31,31,31,33,28,27,24,29,26,26,26,25,33,28]

df = pd.DataFrame(data, columns=['val'])
print (df)

# pct_change列作成
pc = df.pct_change()
df['pc'] = pc
print(df)

# 差分列作成
#df['dif'] =


"""
sr1 = pd.Series(['dif'], index=df.columns)

for i in range(len(df.index)):
    data_frame = data_frame.append(sr1, ignore_index=True)
"""

#l = len(df.index) - 1
df['dif'] = pd.Series(np.array([111]))
df['dif'][0] = 0 # 先頭は0にする
#sr1 = pd.searray([111])
for i in range(1,len(df.index)):
#for i, row in df.iterrow():
    df['dif'][i] = df['val'][i] - df['val'][i-1]

print(df)

# pct_change グラフ
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(df['pc'])
#ax.plot(pc)
ax2 = ax.twinx()
ax2.plot(df['val'],'r')
#plt.show()

# 差分 グラフ
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(df['dif'])
#ax.plot(pc)
ax2 = ax.twinx()
ax2.plot(df['val'],'r')

plt.show()
