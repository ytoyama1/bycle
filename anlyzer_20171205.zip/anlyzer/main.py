#coding:utf-8

import sys # argv 取得用
#import configparser
import numpy as np
import time
from datetime import datetime
import matplotlib.c as plt
from matplotlib.font_manager import FontProperties
#import csv   #csvモジュールをインポート → numpyでやるから不要

import UtilAnalyze as util
from Setting import Setting

fp = FontProperties(fname=r'C:\Windows\Fonts\meiryo.ttc', size=14)

# /// 定数 ///

# 読込CSVファイルカラム
C_IN_COL_FRAME_NO = 0
C_IN_COL_PREDICT_KIND = 1
C_IN_COL_PREDICT_POSSIBILITY = 2
C_IN_COL_TARGET_X = 3
C_IN_COL_TARGET_Y = 4

# 作成データカラム
C_ANA_COL_TIME = 0
C_ANA_COL_DEPTH = 1
C_ANA_COL_AREATOTAL = 2
# 出力ファイルカラム
C_OUT_COL_COUNT = 4
C_OUT_COL_TIME = 0
C_OUT_COL_DEPTH = 1
C_OUT_COL_APPROACH = 2
C_OUT_COL_TAKEPERCENT = 3

c_Array_Axis_Row = 0
c_Array_Axis_Col = 1

# 近接判断距離
#c_Take_Distance = 200 # XXXmm

# 近接カラムデータ
c_Approach_Start = 1 # 近づいた
c_Approach_End = 0 # 離れた

#  設定取得 //////////////////////////////////////////////////////////
setting = Setting()
# 近接判断距離
setting_approach_distance = setting.approach_distance
# 先読み確認用
setting_prefetch_idx = setting.prefetch_idx


# CSVファイルRead
#  In: CSVファイル名
#  Return: Numpy配列
def readCsv( filename ):
    try:
        # names=Trueとすると、各コラムに名前が付いたnumpy.ndarrayが得られる
        ##data_np = np.genfromtxt(filename, delimiter=',', names=True , dtype=("S12", int, int, int, int, int))
        #data_np = np.genfromtxt(filename, delimiter=',', dtype=("S12", int, int, int, int, int))
        data_np = np.genfromtxt(filename, delimiter=',', dtype=("S23", int, int, int, int, int))
        data_np = np.array(data_np.tolist(), dtype=object)
        #header = data_np.dtype.names
        data = np.array(data_np.tolist(), dtype=object)
        return data
    except OSError as err:
        print ("OS error: {0}".format(err))


# 時刻カラムの文字列→DateTime変換
#  In: 文字列時刻データ
#  Return: DateTime
def toDatetime( bdatetime ):
    # Byte → 文字列
    sdatetime = bdatetime.decode('utf-8')
    dt = datetime.strptime(sdatetime, '%H:%M:%S.%f')
    return dt


"""
with open('E:/temp/ShelfSensor_1828.csv', 'r') as f:
    dataReader = csv.reader(f)
    #header = next(dataReader)

    for row in dataReader:
        print( row )
"""
"""
data_np3 = np.genfromtxt(filename, delimiter = ",", dtype = ("S12", int, int, int, int, int) )
data_np3 = np.array(data_np3.tolist(), dtype = object)
print (type(data_np3))
print (data_np3)
"""

#filename = "../data/ShelfSensor_20170731_1412.csv"
filename_in = "../../../data/02_170820120000_640_480_010.csv"

filename_out = "../../../data/02_170820120000_640_480_010_out.csv"


# パラメータ取得
argvs = sys.argv  # コマンドライン引数を格納したリストの取得
argc = len(argvs)  # 引数の個数
print (argvs)
print (argc)
if (argc == 2):  # 引数が足りない場合は、その旨を表示
    filename_in = argvs[1]
elif (argc == 3):
    filename_in = argvs[1]
    filename_out = argvs[2]

# CSVファイル読み込み
start = time.clock()
in_data = readCsv(filename_in)
#print (type(data))
#print (data)
if in_data is None:
    print("Read エラー")
    sys.exit(1)
print ("Elapsed: ", time.clock() - start, "\n")

# 出力ファイル，データ
file_out = None
outdata = None

try:
    if filename_out != "":
        file_out = open(filename_out, 'w')



    # 深度・エリア面積データ作成 ////////////////////////////////////////////
    """
    # 文字列 → 時刻変換
    timedata = ([])
    for ld in data[:,c_Col_Time]:
        timedata = np.append(timedata, toDatetime(ld))
    """

    # 新データ作成
    positiondata = np.c_[
        np.array(in_data[:, C_IN_COL_TARGET_X]),
        np.array(in_data[:, C_IN_COL_TARGET_Y])
        ]
    #print (positiondata)


    # 近接検知確認
    outdata2dim = np.empty((0, C_OUT_COL_COUNT))
    #outdata = np.empty((0, c_ColOut_Count), int)
    anadata = np.array([]) # 取った・戻した分析用データ
    #addcols = np.array([]) # 追加カラム
    approachplotdata = np.array([]) # グラフ表示用データ
    plotval = setting_approach_distance
    fapproach = False
    approachStart = None
    approachEnd = None

    idx = 0
    for ldata in in_data:
        # Depthデータより近接判別。
        if not fapproach:
            # 近接なし状態
            if ldata[C_IN_COL_DEPTH] < setting_approach_distance:
                # 先読みチェック
                if setting_prefetch_idx > 0:
                    # 先読みし，近接なしだったら，状態変化しない
                    if in_data[idx+setting_prefetch_idx][C_IN_COL_DEPTH] >= setting_approach_distance:
                        anadata = np.append(anadata, ldata[C_IN_COL_CNT_APPROACH] + ldata[C_IN_COL_CNT_LEAVE])
                        # グラフ表示ダミーデータ追加
                        approachplotdata = np.append(approachplotdata, plotval)
                        idx += 1
                        continue
                # 近寄った
                # ファイルWrite
                if file_out != None:
                    outdata = "%s, %s, %s, %s\n" % (ldata[C_IN_COL_TIME].decode('utf-8'), ldata[C_IN_COL_DEPTH], c_Approach_Start, 0)
                    file_out.writelines(outdata)

                #approachStart = newdata[c_Col_Time]
                # 近接配列に追加。近接カラム(1)追加
                outdata2dim = np.append(outdata2dim, np.array([[ldata[C_IN_COL_TIME], ldata[C_IN_COL_DEPTH], c_Approach_Start, 0]]), axis=0)
                # 取った・戻した分析データ追加
                anadata = np.append(anadata, ldata[C_IN_COL_CNT_APPROACH] + ldata[C_IN_COL_CNT_LEAVE])
                #approachdata = np.append(approachdata, ldata)
                fapproach = True
                plotval = 0 # グラフ表示ダミーデータ用
        else:
            # 近接中
            if ldata[C_IN_COL_DEPTH] >= setting_approach_distance:
                # 先読みチェック
                if setting_prefetch_idx > 0:
                    # 先読みし，近接だったら，状態変化しない
                    if in_data[idx+setting_prefetch_idx][C_IN_COL_DEPTH] < setting_approach_distance:
                        anadata = np.append(anadata, ldata[C_IN_COL_CNT_APPROACH] + ldata[C_IN_COL_CNT_LEAVE])
                        # グラフ表示ダミーデータ追加
                        approachplotdata = np.append(approachplotdata, plotval)
                        idx += 1
                        continue
                # 離れた
                first, second = util.compare_movement(anadata)
                anadata = np.empty(0)  # クリア
                rate = (first * 100) // second  # パーセント計算（小数点以下切り捨て）
                # ファイルWrite
                if file_out != None:
                    outdata = "%s, %s, %s, %s\n" % (ldata[C_IN_COL_TIME].decode('utf-8'), ldata[C_IN_COL_DEPTH], c_Approach_End, rate)
                    file_out.writelines(outdata)
                #approachStart = newdata[c_Col_Time]
                # 近接配列に追加。近接カラム(1)追加
                outdata2dim = np.append(outdata2dim, np.array([[ldata[C_IN_COL_TIME], ldata[C_IN_COL_DEPTH], c_Approach_End, rate]]), axis=0)
                #approachdata = np.append(approachdata, ldata)
                fapproach = False
                plotval = setting_approach_distance # グラフ表示ダミーデータ用
            else:
                anadata = np.append(anadata, ldata[C_IN_COL_CNT_APPROACH] + ldata[C_IN_COL_CNT_LEAVE])

        # グラフ表示ダミーデータ追加
        approachplotdata = np.append(approachplotdata, plotval)
        idx += 1


    """
    for ldata in newdata:
        # Depthデータより近接判別。
        if not fapproach:
            # 近接なし状態
            if ldata[c_Ana_Col_Depth] < c_Approach_Distance:
                # 近寄った
                #approachStart = newdata[c_Col_Time]
                # 近接配列に追加。近接カラム(1)追加
                #outdata = np.append(outdata, np.append(ldata, np.append(c_Approach_Start, 0)))
                #outdata = np.append(outdata, np.array([ldata[c_ColOut_Time], ldata[c_ColOut_Depth], c_Approach_Start, 0]))
                outdata = np.append(outdata, np.array([[ldata[c_Out_Col_Time], ldata[c_Out_Col_Depth], c_Approach_Start, 0]]), axis=0)
                # 取った・戻した分析データ追加
                anadata = np.append(anadata, ldata[c_Ana_Col_AreaTotal])
                #approachdata = np.append(approachdata, ldata)
                fapproach = True
                plotval = 0 # グラフ表示ダミーデータ用
        else:
            # 近接中
            if ldata[c_Ana_Col_Depth] >= c_Approach_Distance:
                # 離れた
                first, second = util.compare_movement(anadata)
                anadata = np.empty(0) # クリア
                rate = (first * 100) // second
                #approachStart = newdata[c_Col_Time]
                # 近接配列に追加。近接カラム(1)追加
                #addcols = np.array(c_Approach_Start, rate)
                #outdata = np.append(outdata, np.append(ldata, c_Approach_End, addcols))
                #outdata = np.append(outdata, np.append(ldata, np.append(c_Approach_Start, rate)))
                #outdata = np.append(outdata, np.array([ldata[c_ColOut_Time], ldata[c_ColOut_Depth], c_Approach_Start, rate]))
                outdata = np.append(outdata, np.array([[ldata[c_Out_Col_Time], ldata[c_Out_Col_Depth], c_Approach_End, rate]]), axis=0)
                #approachdata = np.append(approachdata, ldata)
                fapproach = False
                plotval = c_Approach_Distance # グラフ表示ダミーデータ用
            else:
                anadata = np.append(anadata, ldata[c_Ana_Col_AreaTotal])
    
        # グラフ表示ダミーデータ追加
        approachplotdata = np.append(approachplotdata, plotval)
    """

    # 出力ファイルCLOSE
    if file_out != None:
        file_out.close()

    print(outdata2dim)
    #for l in outdata:
    #    print (l[c_ColOut_Time], ", ", l[c_ColOut_Depth], ", ",  l[c_ColOut_Approach], ", ",  l[c_ColOut_TakePercent])

    # /// グラフ表示 ///
    # グラフを横に並べる
    fig = plt.figure(figsize=(18, 8))
    ax1 = plt.subplot2grid((1,10),(0,0), colspan=4)
    ax2 = plt.subplot2grid((1,10),(0,5), colspan=5)

    # 深度・エリア面積グラフ表示
    ax1.set_title(u"近接距離・移動量", fontproperties=fp)
    #ax1s = fig.add_subplot(111)
    #ax1.plot(newdata[:,c_ColNew_Time], newdata[:,c_ColNew_Depth], label='Depth')
    ax1.set_ylabel(u'距離:mm', fontproperties=fp)
    ax1.plot(newdata[:, C_ANA_COL_DEPTH], label='Depth')
    ax1.plot(approachplotdata, linestyle="dashed", color="green") # 近接検知
    ax1s = ax1.twinx()
    ax1s.set_ylabel(u'移動量:セル数', fontproperties=fp)
    ax1s.plot(newdata[:, C_ANA_COL_AREATOTAL], 'r')
    ax1.grid(True)
    #plt.show()

    """
    ax1.scatter(data[:,c_Col_X], data[:,c_Col_Y])
    ax1.grid(True)
    """

    """
    # 近接点データ作成
    pointdata = np.c_[
        np.array(data[:,c_Col_X]),
        np.array(data[:,c_Col_Y])]
    #print (newdata)
    # 近接点データXYグラフ表示
    plt.scatter(data[:,c_Col_X], data[:,c_Col_Y])
    plt.title(u"近接点位置", fontproperties=fp)
    plt.xlabel(u'X-位置', fontproperties=fp)
    plt.ylabel(u'Y-位置', fontproperties=fp)
    plt.grid(True)
    #plt.show()
    """

    ax2.scatter(in_data[:, C_IN_COL_X], in_data[:, C_IN_COL_Y], s=100, c=in_data[:, C_ANA_COL_DEPTH], cmap='Blues')
    ax2.set_title(u"近接点位置", fontproperties=fp)
    ax2.set_xlabel(u'X-位置', fontproperties=fp)
    ax2.set_xlim(0, 64)
    ax2.set_ylabel(u'Y-位置', fontproperties=fp)
    ax2.set_ylim(0, 24)
    ax2.grid(True)

    plt.show()

#except IndexError:
#    print ('Usage: %s TEXTFILE' % script_name)
except IOError:
    print ("エラー: IOError")
    sys.exit(1)
except:
    print(sys.exc_info())
    sys.exit(1)
finally:
    if file_out != None:
        file_out.close()
    print ("/// 処理終了 ///")
