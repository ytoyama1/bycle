#coding:utf-8

import os
import sys
import csv
import math
import numpy as np
import pandas as pd

"""
動画から作成したCSVファイルを成形する。
"""

SETTING_FILE_FRAME_CNT = 18000 # 3FPSの10分: 10×60×3
SETTING_FILE_PATH = "E:/Project/Bicycle/data/result/"
#SETTING_FILE_IN_1 = SETTING_FILE_PATH + "02_170820120000_640_480.csv"
#SETTING_FILE_IN_2 = SETTING_FILE_PATH + "02_170820121000_640_480.csv"
#SETTING_FILE_IN_3 = SETTING_FILE_PATH + "02_170820122000_640_480.csv"
#SETTING_FILE_IN_4 = SETTING_FILE_PATH + "02_170820123000_640_480.csv"
#SETTING_FILE_IN_5 = SETTING_FILE_PATH + "02_170820124000_640_480.csv"
#SETTING_FILE_IN_6 = SETTING_FILE_PATH + "02_170820125000_640_480.csv"
#SETTING_FILE_OUT = SETTING_FILE_PATH + "02_1708201200.csv"
SETTING_FILE_IN_1 = SETTING_FILE_PATH + "02_170820160000_640.csv"
SETTING_FILE_IN_2 = SETTING_FILE_PATH + "02_170820161000_640.csv"
SETTING_FILE_IN_3 = SETTING_FILE_PATH + "02_170820162000_640.csv"
SETTING_FILE_IN_4 = SETTING_FILE_PATH + "02_170820163000_640.csv"
SETTING_FILE_IN_5 = SETTING_FILE_PATH + "02_170820164000_640.csv"
SETTING_FILE_IN_6 = SETTING_FILE_PATH + "02_170820165000_640.csv"
SETTING_FILE_OUT = SETTING_FILE_PATH + "02_1708201600.csv"
#SETTING_FILE_IN_1 = SETTING_FILE_PATH + "02_170820170000_640.csv"
#SETTING_FILE_IN_2 = SETTING_FILE_PATH + "02_170820171000_640.csv"
#SETTING_FILE_IN_3 = SETTING_FILE_PATH + "02_170820172000_640.csv"
#SETTING_FILE_IN_4 = SETTING_FILE_PATH + "02_170820173000_640.csv"
#SETTING_FILE_IN_5 = SETTING_FILE_PATH + "02_170820174000_640.csv"
#SETTING_FILE_IN_6 = SETTING_FILE_PATH + "02_170820175000_640.csv"
#SETTING_FILE_OUT = SETTING_FILE_PATH + "02_1708201700.csv"


def file_append(pfilename, pdestfilename, pmode='a'):
	df = pd.read_csv(pfilename, header=None)
	df.to_csv(pdestfilename, mode= pmode, index=False, header=None)

"""
フレーム番号を累積する
"""
def file_accumu_frame_num(pInFilenames, pOutFilename):

	fin = None
	fout = None
	try:
		fout = open(pOutFilename, 'w', newline='')
		writer = csv.writer(fout)
		for fn in pInFilenames:
			plusfrm = SETTING_FILE_FRAME_CNT*(pInFilenames.index(fn))
			try:
				with open(fn, 'r', newline='') as fin:
					# READ
					reader = csv.reader(fin)
					for row in reader:
						#print( row )
						frmno = (int)(row[0])
						if frmno >= SETTING_FILE_FRAME_CNT:
							break
						#WRITE
						row[0] = str(frmno + plusfrm)
						writer.writerow(row)

			except Exception as ex:
				print("例外エラー：", ex.args)
			finally:
				if fin is not None:
					fin.close()

	except Exception as ex:
		print("例外エラー：", ex.args)
	finally:
		if fout is not None:
			fout.close()


print ("/// Start Data Cleansing ///")

# CSVファイル取得
#path, ext = os.path.splitext(filename_video)
#path = "E:/Project/Bicycle/data/result/"
#filename_csv = path + ".csv"

list_fn = [SETTING_FILE_IN_1, SETTING_FILE_IN_2, SETTING_FILE_IN_3, SETTING_FILE_IN_4, SETTING_FILE_IN_5, SETTING_FILE_IN_6 ]
file_accumu_frame_num(list_fn, SETTING_FILE_OUT)

print ("/// End Data Cleansing ///")
