import configparser

class Setting :

    # グローバル変数

    # 設定ファイル名
    C_SETTING_FILENAME = "setting.ini"
    # 設定ファイル項目キー
    C_KEY_SECTION_SENSORr = 'Sensor'
    C_KEY_APPROACH_DISTANCE  = 'ApproachDistance'
    C_KEY_PREFETCH_INDEX  = 'PrefetchIndex'

    approach_distance = 0
    prefetch_idx = 0

    def __init__(self):
        # 設定ファイル名

        config = configparser.ConfigParser()
        config.sections()
        config.read(self.C_SETTING_FILENAME)

        self.approach_distance = int(config[self.C_KEY_SECTION_SENSORr][self.C_KEY_APPROACH_DISTANCE])
        self.prefetch_idx  = int(config[self.C_KEY_SECTION_SENSORr][self.C_KEY_PREFETCH_INDEX])
        print(self.approach_distance)
        print(self.prefetch_idx)


    def get_approach_distance(self):
        return self.approach_distance

    def get_prefetch_idx(self):
        return self.prefetch_idx

"""
config.sections()
s = 'bitbucket.org' in config
print(s)
s = 'bytebong.com' in config
print(s)
s = config['bitbucket.org']['User']
print(s)
self.approach_distance = config['DEFAULT']['Compression']
print(s)
topsecret = config['topsecret.server.com']
s = topsecret['ForwardX11']
i = topsecret['Port']
print(s, " ", i)

# /// Config Write
config = configparser.ConfigParser()
config['DEFAULT'] = {'ServerAliveInterval': '45',
                      'Compression': 'yes',
                      'CompressionLevel': '9'}
config['bitbucket.org'] = {}
config['bitbucket.org']['User'] = 'hg'
config['topsecret.server.com'] = {}
topsecret = config['topsecret.server.com']
topsecret['Port'] = '50022'     # mutates the parser
topsecret['ForwardX11'] = 'no'  # same here
config['DEFAULT']['ForwardX11'] = 'yes'
with open('setting.ini', 'w') as configfile:
    config.write(configfile)
"""

