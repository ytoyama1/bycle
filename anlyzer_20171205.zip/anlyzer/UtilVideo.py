#coding:utf-8

import sys
import cv2

#C_VIDEO_FPS = 30.0
C_VIDEO_FPS = 3.0
C_VIDEO_WIDHT = 640
C_VIDEO_HEIGHT = 480

class UtilVideo:

	#mVideo = None

	# コンストラクタ
	def __init__(self, pfilename, pfps = C_VIDEO_FPS, psizew = C_VIDEO_WIDHT, psizeh = C_VIDEO_HEIGHT):
		try:
			if pfilename != "":
				fourcc = cv2.VideoWriter_fourcc('m', 'p', '4', 'v')
				video = cv2.VideoWriter(pfilename, fourcc, pfps, (psizew, psizeh))
				self.video_file = video
				self.video_width = psizew
				self.video_height = psizeh
			else:
				print("エラー: ファイル名未指定")

		except IOError:
			print("Openエラー: IOError")

		except:
			print("Openエラー: " + sys.exc_info())

	# デストラクタ
	def __del__(self):
		if self.video_file != None:
			self.video_file.relese()
		print("/// FileUtil終了 ///")

	def releseVideo(self):
		if self.video_file != None:
			self.video_file.release()
		print("/// FileUtil終了 ///")

	# Write データ
	def writeImage(self, img, times=1 ):
		try:
			if self.video_file != None:
				img = cv2.resize(img, (self.video_width, self.video_height))
				for i in range(times):
					self.video_file.write(img)
			return

		except IOError:
			print("Writeエラー: IOError")
			return
		except:
			print("Writeエラー: " + sys.exc_info())
			return

