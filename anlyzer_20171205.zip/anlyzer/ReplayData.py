#coding:utf-8
"""
動画より作成したCSVファイル（結合ファイル可）をもとに
軌跡を表示する動画を作成する
"""
import os
import sys
import cv2
import math
import numpy as np
import pandas as pd
from UtilVideo import UtilVideo

SETTING_TIME = "17:"
SETTING_FRAME_DISTANCE = 30*3 # 1秒30フレーム
SETTING_POINT_DISTANCE = 100 # 2点間距離
SETTING_DISPLAY_VIDEO = False
SETTING_WAIT_FRAME = True

# ファイル名
#SETTING_IN_CSV = "E:/Project/Bicycle/data/result/02_1708201200.csv"
#SETTING_OUT_VIDEO = "E:/Project/Bicycle/data/result/02_1708201200_out_bicycle.mp4"
SETTING_IN_CSV = "E:/Project/Bicycle/data/result/02_1708201700.csv"
SETTING_OUT_VIDEO = "E:/Project/Bicycle/data/result/02_1708201700_out_bicycle.mp4"
SETTING_BK_PIC = "E:/Project/Bicycle/data/result/ImageBlank1_3.jpg"



def open_csv(filename):
	#data = np.loadtxt(filename, delimiter=',', skiprows=1)
	data = pd.read_csv(filename, skipinitialspace=True)
	return data

def file_append(pfilename, pdestfilename, pmode='a'):
	df = pd.read_csv(pfilename, header=None)
	df.to_csv(pdestfilename, mode= pmode, index=False, header=None)

	#f = open(pdestfilename , 'a')
	#for line in open(pfilename, 'r'):
	#	f.write(list)
	#	f.newlines
	#f.close()

def calc_distance(x1, y1, x2, y2):
	a = np.array([x1, y1])
	b = np.array([x2, y2])
	u = b - a
	d = np.linalg.norm(u)

	#return int(d)
	return d

#def draw_Arrow(img, pt1, pt2, color, thickness=1, lineType=8, shift=0):
def draw_Arrow(img, pt1, pt2):
	#thickness = 5
	thickness = 3
	lineType = 8
	shift = 0
	vx = pt2[0] - pt1[0]
	vy = pt2[1] - pt1[1]
	if vx == 0 and vy == 0:
		return
	if vx > 0:
		color = (255, 0, 0)
	else:
		color = (0, 0, 255)
	cv2.line(img, pt1, pt2, color, thickness, lineType, shift)
	v  = math.sqrt(vx ** 2 + vy ** 2)
	ux = vx / v
	uy = vy / v
	# 矢印の幅の部分
	w = 5
	h = 10
	ptl = (int(pt2[0] - uy*w - ux*h), int(pt2[1] + ux*w - uy*h))
	ptr = (int(pt2[0] + uy*w - ux*h), int(pt2[1] - ux*w - uy*h))
	# 矢印の先端を描画する
	cv2.line(img,pt2,ptl,color,thickness,lineType,shift)
	cv2.line(img,pt2,ptr,color,thickness,lineType,shift)


print ("/// Start ReplayData ///")

# CSVファイル取得
#path, ext = os.path.splitext(filename_video)
#filename_csv = path + ".csv"
#filename_csv = "E:/Project/Bicycle/data/result/02_1708201200.csv"
#filename_csv = "E:/Project/Bicycle/data/result/02_170820120000_640_480.csv"
filename_csv = SETTING_IN_CSV

"""
filename_csv1 = "E:/Project/Bicycle/data/result/02_170820120000_640_480.csv"
filename_csv2 = "E:/Project/Bicycle/data/result/02_170820121000_640_480.csv"
filename_csv3 = "E:/Project/Bicycle/data/result/02_170820122000_640_480.csv"
filename_csv4 = "E:/Project/Bicycle/data/result/02_170820123000_640_480.csv"
filename_csv5 = "E:/Project/Bicycle/data/result/02_170820124000_640_480.csv"
filename_csv6 = "E:/Project/Bicycle/data/result/02_170820125000_640_480.csv"
# ファイル結合
file_append(filename_csv1, filename_csv, 'w' )
file_append(filename_csv2, filename_csv)
file_append(filename_csv3, filename_csv)
file_append(filename_csv4, filename_csv)
file_append(filename_csv5, filename_csv)
file_append(filename_csv6, filename_csv)
"""

# ファイルOpen
data = open_csv(filename_csv)

# 背景画面
# 背景イメージファイルまたはビデオファイルから，イメージ作成
#filename_video = "E:/Project/Bicycle/data/result/ImageBlank1_2.jpg"
filename_video = SETTING_BK_PIC
#filename_video = "E:/Project/Bicycle/data/result/02_170820123000_640_480_out.mp4"
vid = cv2.VideoCapture(filename_video)
if not vid.isOpened():
	print ("ビデオファイルをOpenできませんでした")
	sys.exit(1)
res, frame_read = vid.read()
while frame_read[0].max() == 0:
	res, frame_read = vid.read()

# 出力ビデオファイル
#video_filename = "E:/Project/Bicycle/data/result/02_170820123000_640_480_out_bicycle.mp4"
#video_filename = "E:/Project/Bicycle/data/result/02_1708201200_out_bicycle.mp4"
video_filename = SETTING_OUT_VIDEO
#mVideoFile = UtilVideo(video_filename, 10)
mVideoFile = UtilVideo(video_filename, 30)


font = None
outline_font = None

fend = False
fclear = False
frame_draw = frame_read.copy()
row_save = []
for idx, row in data.iterrows():
	#if fclear == True:
	#	frame_draw = frame_read.copy()
	if row[1] == "bicycle" or row[1] == "motorbike" :
		# フレーム数の時刻表示
		isec = int(row[0] / 30)
		#text = "+ {0:02d}:{1:02d}".format(isec//60, isec%60)
		text = SETTING_TIME + "{0:02d}:{1:02d}".format(isec // 60, isec % 60)
		text_pos = (500, 33)
		# 時刻背景
		recty = 5
		rectx = 485
		clr = (192, 192, 192)
		cv2.rectangle(frame_draw, (rectx, recty), (rectx+150, recty+40), clr, -1)
		clr = (128, 0, 0)
		cv2.rectangle(frame_draw, (rectx, recty), (rectx+150, recty+40), clr, 1)
		igap = 3
		cv2.rectangle(frame_draw, (rectx+igap, recty+igap), (rectx+150-igap, recty+40-igap), clr, 2)
		# 輪郭の描画
		clr = (255, 0, 0)
		cv2.putText(frame_draw, text, text_pos, cv2.FONT_HERSHEY_SIMPLEX, 0.8, clr, 4)
		# 文字の描画
		#clr = (255, 255, 0) # CYAN
		#clr = (212, 255, 127) # AQUAMARINE
		clr = (255, 255, 224) # LIGHTCYAN
		cv2.putText(frame_draw, text, text_pos, cv2.FONT_HERSHEY_SIMPLEX, 0.8, clr, 2)
		# 中点表示
		#if len(row_save) > 0:
		#	cv2.circle(frame_draw, (row_save[3], row_save[4]), 10, (255, 0, 0), 2)
		#cv2.circle(frame_draw, (row[3], row[4]), 10, (255, 0, 0), 2)
		cv2.circle(frame_draw, (row[3], row[4]), 5, (0, 0, 0), 2)
		wait_time = 50
		# フレームが範囲以内で間隔が範囲以内なら，軌跡線表示
		if len(row_save) > 0:
			if (row[0] - row_save[0]) < SETTING_FRAME_DISTANCE and calc_distance(row_save[3], row_save[4], row[3], row[4]) < SETTING_POINT_DISTANCE:
				#draw_Arrow(frame_draw, (row_save[3], row_save[4]), (row[3], row[4]), (255, 0, 0), 5)
				draw_Arrow(frame_draw, (row_save[3], row_save[4]), (row[3], row[4]))
				if SETTING_WAIT_FRAME:
					#mVideoFile.writeImage(frame_draw, 5)
					#mVideoFile.writeImage(frame_draw, 3)
					mVideoFile.writeImage(frame_draw, 1)
				fclear = False
				wait_time = 100
			else:
				if SETTING_WAIT_FRAME:
					#mVideoFile.writeImage(frame_draw, 10)
					#mVideoFile.writeImage(frame_draw, 5)
					mVideoFile.writeImage(frame_draw, 3)
				fclear = True
				wait_time = 500
		if SETTING_DISPLAY_VIDEO == True:
			cv2.imshow("Tracking", frame_draw)
			if cv2.waitKey(wait_time) == 27:
				fend = True
				break
		#直前データ保存
		row_save = row

if fend == False:
	cv2.waitKey(5000) == 27
"""
if vid != None:
	vid.release()
"""

if mVideoFile != None:
	mVideoFile.releseVideo()
cv2.destroyAllWindows()
# 入力CSVファイル

print ("/// End ReplayData ///")
